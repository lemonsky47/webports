﻿# The script of the game goes in this file.

# Declare characters used by this game. The color argument colorizes the
# name of the character.

define e = Character("    ")
define t = Character("Y/N")
define z = Character("Miss Circle")
define c = Character("Mister Compass")
define g = Character("Miss Grace")
define h = Character("Miss Thavel")
define m = Character("Miss Bloomie")
define w = Character("Miss Sasha")
define k = Character("Mister Demi")
define b = Character("Miss Emily")

#The game starts here.

label start:
    play music "coffee.ogg"

    scene brickroom

    e "Hello and welcome to my FPE Fangame, YN!"

    e "I hope you enjoy this dating game!"

    e "Please pick a gender!"

    
    menu:
        e "What gender are you?"
        "Male":
            e "You Picked Male!"
        "Female":
            e "You Picked Female!"
        "Non-Binary":
            e "You Picked Non-Binary!" 

    scene outside

    e "You were a new teacher at paper school. You took the job because you were not qualified for the other school you appiled for which was a much better school than your... second option paper school."

    e "You were nervous. But you had to go through with it. Nothing bad will happen... right?"

    e "It was just a normal school like anyother."

    e "You took the geography job. It was the subject you took college for and because your not qualified for any other subjects"

    e "You hope this was a good idea and that you did not make a mistake doing this. It was the last school in the town and the other schools were 2 hours away."

    scene hallway

    e "You walk into the school and bump into one of the other teachers. This one was very tall, has a compass tool for her arm, and had an oreo in her mouth"

    show misscircle confused

    e "you see the hindge on the compass blink with a shiny blue eye. You rub your eyes and the blue eye on the compass was gone"

    z "Eh..?"

    z "Who are you?"

    t "Im the new geography teacher"

    z "You are? Grace was talking about a new hire..."

    show misscircle smug

    z "Oh I almost forgot. My name is Miss Circle. I am the math teacher of this school and the best and most stunning teacher here!"

    t "My names Y/N Miss"

    show misscircle suprised

    z "Oh.. Thats strange..."

    z "Y/N... I havent ever heard that name before..."

    t "Well thats my name"

    z "Your not from around here are you?"

    z "Wait... No way."

    show misscircle smug

    z "Your almost as short as Bloomie hahaha! Your lucky your still taller than her. Only by a little bit though~"

    z "You should see her! Shes a fucking midget of an adult Hahaha"

    z "Ohh... Anyway.."

    z "So your starting your new job? I guess I should tell you where to go first."

    z "Go to Miss Grace. Shes the principal. She will be wanting to see you for your first day. See you soon~"

    e "You stand there, confused"

    z "You going yet?"

    t "Miss Circle? Do you think you could show me where Miss Grace is?"

    e "You ask this nervously, her unnatural tall frame scaring you a little"
            
    show misscircle suprised
            
    t "Uh.. Please?"
            
    show misscircle smug

    z "You want me to show you around? Why I think you just want to hang out heh~"

    z "The short newbie wants to hang out with me hahaha~"

    e "A small blush forms as she made fun of your height"

    t "Hey! Im not that short!"

    z "Is that what you think? I think your pretty short~"

    t "Im the regular height for a person! You're just really tall!"

    z "Uh huh. Shortie~"

    show misscircle serious

    e "Miss circle sighs, her expression turning serious"

    z "Anyways. No. I don't think I can show you around Y/N. I have... students to rally up."

    z "It would be the best for you to go to the principal now. She does'nt like to be kept waiting. Wander around if you have too."

    t "Oh. Alright then"

    hide misscircle serious

    e "You start heading though the halls looking for Miss Grace's office"
        
    e "As you walk through the hallway you see a door"

    e "The door had a name plate that said 'Principals Office Room 319'"

    scene office

    show missgrace blank

    e "You open the door to see a woman with white hair, in a green suit with a long black skirt, a monocle, black horns and on one of the horns was a piece of paper with a strange triangle symbol"

    g "Who are you.."

    t "Uh Im the new... geography teacher"

    e "Miss Grace stares at you, thinking about something"

    g "Ah the new hire. Y/N correct?"

    t "Yeah thats my name."

    e "You were nervous about meeting the principal of the school and you wanted to make a good impression."

    t "Your the principal, Miss Grace right?"

    t "I uh like your suit. Green really suits you!"

    show missgrace small blush

    g "Ah... Thank you very much."

    t "No problem"

    e "Miss Grace sighs"

    g "Alright then... The geography classroom is Room 273"

    t "Alright. Thanks"

    g "Settle into the classroom. you wont have students for awhile."

    e "You start heading to the door"

    show missgrace closedeyes

    e "Miss Grace sighs"

    g "Wait... One more thing"

    e "You turn around suprised and confused"

    t "Yes Miss Grace?"

    show missgrace small blush

    g "..Have a good day Y/N"

    t "You too Grace!"

    e "You leave her office"

    scene hallway2

    e "You start heading to your classroom when you see a short-ish woman with a...boxcutter for an arm?"

    e "You continue walking to your classroom, trying to avoid interupting the teacher from whatever she was doing but she notices you."

    e "She walks up to you and looks up at your face, inspecting you"

    show missbloomie interested

    m "Hello. You must be the new geography teacher. Miss Circle... told me about you."

    m "I am the science teacher here."

    t "Miss Bloomie r-right?"

    m "Yes I am Y/N."

    m "So what did Miss Circle tell you about me?"

    t "Oh! uhm..."

    show missbloomie angry

    m "My height right?"

    e "Miss Bloomie looks down and grumbles, obviously a little angry just by mentioning the topic of her height"

    t "Yeah.. she did mention it..."

    m "Wow this fucking fatass bitch can't stop mentioning my height. Fucking giant diabetic oreo muncher"

    e "She was very pissed at Miss Circle for mentioning her height at all"

    m "If Grace would let me Id kill that fat bitch"

    e "You back up slowly, concerned her anger would start to be targeted at you"

    t "Well then.. I was heading to my classroom so ill be going then"

    m "Hold. Did fatass Oreo Muncher say anything else about me?"

    t "Not really... She just made comments on how short I am... refrencing you.."

    m "Ugh. She makes those fucking short jokes 500 times a day I swear"

    m "So fucking annoying. I'd beat the shit out of her if I could"

    m "And she never says anything else!"

    t "Oh... uhm... alright Bloomie"

    t "I think I should go to my classroom now.."

    show missbloomie blank

    e "Miss Bloomie looks up at you her anger gone, replaced by a blank look"

    m "Oh. Alright Y/N. Ill see you during Lunch break then"
    
    scene hallway3

    e "You walk through the halls till you arrive at your classroom."

    scene geographyclass

    e "You see a bunch of boxes in the classroom, each filled with the basic materials, a globe, and a lot of reading books"
    
    e "You walk to you're desk and sit down in the chair. You spun around in it for a hot minute until you realize your acting like a kid."

    e "You immediately stopped spinning in you're chair and felt embarrased"

    t "What am I doing... Im not a kid.."

    e "You stood staring at the boxes for a moment, some of the boxes were already opened. The desks were neatly arranged."

    e "You start unpacking the boxes and setting up your classroom to your desire"
    
    e "The the bell rings, signaling the start of the next period. You ignore it and continue unpacking"

    scene black

    e "2 hours and 20 minutes later"

    scene breakroom

    e "You opened the door to the breakroom to find it suprisingly empty"

    e "You were in the breakroom and you take out your lunch, which was some corn chowder."

    e "You put the bowl of corn chowder in the microwave for 2 minutes"

    e "Someone walks in and you turn around"

    show missthavel blank
    
    e "You see a woman with deer horns, a small fluffy tail, and a A B C headband on her head"

    e "Her suit was a little ripped and tattered and her hair a little messy"

    show missthavel suprised

    h "Oh my.. hello. I didnt expect you to be here.." 
    
    h "You're the new teacher right? What are you teaching?"

    t "Oh uhm Im teaching geography"

    show missthavel happy

    h "Thats cool! How did the kids treat you?"

    t "Havent met the kids yet but one of the teachers called me short..."

    show missthavel annoyed

    e "She looks away thinking, an annoyed look on her face"

    h "tch.. of course."

    h "That stupid fucking bitch.. Ill-"

    e "She stops and looks at you, her annoyed look going away as quickly as it came"

    show missthavel happy

    h "Anyways whats your name?"

    t "My names Y/N"

    h "Thats a pretty name!"

    e "A blush creeps up on your face and you look away"

    t "Thanks..."

    h "No problem! Im Miss Thavel the language teacher here!"

    t "Yeah? What languages do you teach?"

    show missthavel proud

    h "All! Any! Want me to list them?"

    h "I can if you want?"

    t "Oh no thanks. I learned a lot in highschool and college. Thanks for asking"

    e "Thavels proud look never falters"

    h "Heh no problem!"

    h "I love helping new teachers around. I helped Miss Bloomie on her first day!" 
    
    h "Do you need to know where anything is dear?"

    t "I think I got it!"

    h "Alright then! Your foods done by the way."

    e "You get up and get your food bowl full of corn chowder"

    show missthavel interested

    h "Ooooo whats that"

    t "Its my favorite food, corn chowder?"

    h "Can I try some? Please?"

    t "Fine.."

    show missthavel happy

    e "Miss Thavel takes the spoon, dips it in the corn chowder and take a bite, accidently slurping a little"

    h "Thats delicious! I love it!"

    t "I'm glad!"

    h "Well I should be going! See you later Y/N!"

    t "Oh uh see you later!"

    e "Miss Thavel turns and walks out waving a goodbye"

    e "You wave a back clearly a little anxious"

    e "You finish eating your lunch and you get up to wash you're hands"

    e "After your done you put everything away and head to you're classroom"

    scene geographyclass

    e "After school was over and you were done teaching the kids, you felt exhausted so you laid back in you're office chair"

    e "Miss Bloomie walked in behind you, with a blank expression"

    show missbloomie blank

    m "Y/N. How was your first day?"

    t "Oh Miss Bloomie! Uhm it was pretty good. I got to meet some of the teachers"

    m "Good. We didn't get enough time to speak to eachother last time"

    t "Is there something you wanted to speak about?"

    m "Yes. I wanted to ask if we could... hug..."

    show missbloomie blush

    e "Miss Bloomie was a little embarrased but had a little hope you would say yes"

    menu:
        m "Could we... hug?"
        "Yes":
            show missbloomie hug
            m "Thank you..."
        "No":
            show missbloomie dissapointed
            e "Miss Bloomies embarrasment fades away into a blank expression"
        
    show missbloomie blank

    m "Alright. Ill be heading home now. See you tomorow Y/N"

    e "Bloomie grabbed her things and headed out the door"

    e "You felt even more tired with the interaction draining what was left of your energy"

    e "You got up and grabbed your laptop, and bag and walked out the door"

    show black

    play music "brushes.ogg"

    scene geographyclass

    e "It was the next tiring school day and you headed to you're classroom as usual and waited before finishing unpacking the boxes"

    e "You didnt get too much sleep last night due to your noisy nieghbors"

    e "They were fighting about the fence separating their properties. Stuff you didn't care about and you didn't wanna listen too"

    e "Some time later..."

    t "Unpacking these boxes can really be a handful.."

    e "You sigh as your pretty tired."

    e "You get up to open the door as you hear a knock"

    show misterdemi shy

    e "You open the door to see a shy man looking man with piano like keys dyed in his hair"

    t "Oh uh hello. Who.. are you?"

    k "Oh u-uh h-hi... Im M-Mister Demi..."

    k "W-Whats your name..?"

    t "Oh uh I'm Y/N. The new geograhpy teacher"

    t "Your the music teacher right?"

    show misterdemi surprised

    k "Uhm y-yeah! H-how did y-you know?"

    e "You look at the music refrences on Mister Demi"

    menu:
        "What do you say?"
        "Oh uhm... Just a hunch heheh":
            show misterdemi surprised
            k "Oh uh a-alright.."
        "From the music refrences on you...":
            show misterdemi embarrassed 
            k "O-oh... right i'm s-stupid"
    
    e "You look at Demi feeling sympathy"

    t "So how was your day today?"

    k  "It was g-good.. w-what about y-you?"

    t "Tiring..."

    show misterdemi concerned

    k "Oh g-goodness.. I h-hope you f-feel better s-soon"

    e "The bell rings signaling the end of the other students class"

    k "Oh w-well I must g-go.. See you l-later Y/N.."

    e "Mister Demi leaves as you go sit down at you're desk."

    e "You didn't have a class for the rest of the day as the principal wanted you to ease into the job."

    e "You wanted to explore the school a little more so you stood up."

    scene hallway

    e "You walked past a couple lockers when you find the art room."

    e "You decide to open the door to see who was in there."

    scene artroom

    show misssasha headphones

    e "You see a pretty woman wearing a nice red hat with thick rainbow strings dangling from the brim of the hat."
    
    e "There was a light green book covering one side of her face. You look around more to see her cleaning her classroom with some headphones on."

    e "She was humming the tune of the music while cleaning the rest of the desks."

    e "Sasha finishes cleaning and she takes off her headphones. She puts them in her bag and then she notices you standing in the doorway."

    show misssasha surprised

    w "Oh! You startled me dear!"

    e "Sasha looked startled and embarrased"

    t "Yeah.. Sorry for sneaking up on you like that.."

    show misssasha embarrassed

    w "Its alright... "

    menu:
        "What should you say?"
        "Compliment her cleaning":
            t "Uhm... Whats your name?"

            show misssasha surprised
             
            w "Oh uhm Im Miss Sasha, the art teacher. You may call me Sasha. Whats your name?"

            t "Ah my name is Y/N. Im the new geography teacher. I saw you cleaning earlier Sasha. You did a pretty good job"

            t "Do you have any other talents Sasha?"

            show misssasha determined

            w "Heh of course. Im good at art of course. Im the art teacher after all hehe!"

            w "Im also good at baking. Baking is my hobby! Ive made birthday cakes, regular cakes, pastries, and all sorts of goodies hehe"

            show misssasha blush

            w "Maybe I could show you my baking skills some day dear heheh"

            t "I would be glad if you did. Thanks for the offer."

            w "No problem. Talking with you made my day heh"
        "Compliment her hair":

            t "I really like the way you did your hair.."

    show misssasha worried

    e "Sasha looks at the clock then sighs"

    w "Its about time to leave... schools ending for the day.."

    t "Ah yes.. Maybe I can actually get some sleep tonight"

    w "You didnt get sleep last night? Oh gosh.."

    t "No I didnt. My neighbors were arguing about something stupid and they were pretty loud"

    w "Oh goodness... Im sorry about that."

    t "Its ok. Its nothing you couldve controlled"

    e "The bell rings signaling the end of the school day"

    w "Ah well its time to leave... Thank you for talking with me dear."

    w "I really enjoyed our time together."

    e "Sasha picks up her bag and walks off, heading home"

    e "You walk out of her classroom and into the hallway"

    scene hallway

    e "As you walk out you stumble into a woman with puffy black hair and a black, white dotted dress"

    show missemily pleased

    b "Ah! there you are Y/N. Im Miss Emily the history teacher. I was looking for you."

    t "You were? What do you need me for?"

    b "Yes I was. Miss Grace needs to see you before you leave."

    t "Oh alright. Ill go see her"

    show missemily happy

    b "Ah thank you Y/N. Grace will be happy"

    b "She is pleased with what you did with your classroom"

    b "Heh.. It was good to meet you Y/N. Even if it was a small meeting."

    e "Emily walks away towards the exit while you head to miss graces office"

    e "You see her office door and head into her office"

    scene office

    show missgrace pleased

    g "Ah Y/N your here! Good good.."

    g "I saw what you did with your classroom. It looked nice"

    menu:
        "What do you say to Miss Grace"
        "Thank you Grace. Your office looks nice as well":
            show missgrace small blush
            g "Thanks Y/N. You're too sweet for your own good."
        "Oh shut up. Why do you need me anyway.":
            show missgrace angry
            e "That was quite rude of you"
            g "I wanted to warn you, you good for nothing-!"
        
    e "Miss Grace sighs"

    show missgrace tired
    
    g "Listen. Circle, Bloomie, and Thavel are dangerous. Dont test them. They will most likely hurt you"

    g "Trust me... Ive been with them for years to know.."

    g "One last warning. Never enter the blue door that says 'Alices Room'"

    t "Uhm ok Grace. I get it."

    e "She sighs again, hoping you do as she says"

    g "Good. Now. See you tomorow"
    
    g "Hope you have a goodnight Y/N"

    e "You leave the building, feeling weary of the warnings she gave you"

    scene black

    play music "end.ogg"

    e "You arrive at the school after a long days rest"

    scene outside

    e "You walk into the school to see some new adult you havent met"

    e "This adult had blue eyes and black claws. You realize he looks kinda like Miss Circle"

    scene hallway2

    show mistercompass blank

    t "Uhm hello sir.. might I ask who are you?"

    show mistercompass suspicious

    c "Who am I? Im.. Mister Compass. Now who might you be.. Ive seen Miss Circle talking to you"

    t "Oh uh I am the new geography teacher.. nice to meet you Mister Compass"

    show mistercompass grumpy

    c "Its not nice to meet you! And of course you teach something stupid"

    t "Geographys not stupid.. Miss Circle thinks what I teach is cool!"

    c "Oh shut up! Just cause Miss Circle likes you doesnt mean I have to like you."

    c "Your probably just full of yourself!"

    menu:
        "Hes quite rude.. What do you say"
        "You're not very kind Mister Compass":
            show mistercompass angry
            c "Oh shut up! No one asked you!"
        "You're an asshole arent you":
            show mistercompass angry
            c "Fuck you, you short bitch!"

    show mistercompass angry
    
    c "Why does Miss Circle like you so much!?"

    c "Im leaving!"
    
    hide mistercompass angry
    
    e "As Mister Compass leaves you wonder who he is and what hes doing here"

    e "And why is he so rude!?"

    e "You have reached the time to choose who you will date"

    e "Choose Wisely (Some Characters are currently unavailable)"

    menu:
        "Who will you date? (Mister Compass and Miss Emily are unavailable)"
        "Miss Circle":
            show misscircle confused
            t "Hey uh.. I have to confess.. I love you Circle"
            show misscircle smug
            z "I knew you loved me, Im the most beautiful teacher after all"
            z "Wanna come to my house to eat oreos and watch funny car crashes?"
            t "Sure"
            hide misscircle smug
            scene endoreo
            e "THANKS FOR PLAYING"
        "Miss Thavel":
            show missthavel interested
            t "Hey uh.. I have to confess.. I love you Thavel"
            show missthavel happy
            h "Me? Awh you love me? I love you too hehe"
            h "I was just about to go hunting if you want to come with"
            t "Uhm sure"
            hide missthavel happy
            scene endwendigo
            e "THANKS FOR PLAYING"
        "Miss Bloomie":
            show missbloomie blank
            t "Hey uh.. I have to confess.. I love you Bloomie"
            show missbloomie blush
            m "A-ah... you.. love me..?"
            m "I.. I love you too.. Give me a hug"
            show missbloomie hug
            m "Want to hold hands..?"
            t "sure"
            hide missbloomie hug
            scene endholdinghands
            e "THANKS FOR PLAYING"
        "Miss Grace":
            show missgrace tired
            g "Yes Y/N? What do you need"
            t "Hey uh.. I have to confess.. I love you Grace"
            show missgrace small blush
            g "Oh my.. Well "
            g "Well then uh... Would you like to go get some Ice Cream..?"
            hide missgrace small blush
            scene endicecream
            e "THANKS FOR PLAYING"
        "Mister Demi":
            show misterdemi shy
            t "Hey uh.. I have to confess.. I love you Demi"
            show misterdemi embarrassed
            k "O-oh! You.. Love me?" 
            k "hehe.. would you like to make music with me then..?"
            t "yeah.. Id love that"
            hide misterdemi embarrassed
            scene endmusic
            e "THANKS FOR PLAYING"
        "Miss Sasha":
            show misssasha surprised
            t "Hey uh.. I have to confess.. I love you Sasha"
            show misssasha blush
            w "Ohh goodness me.."
            w "I love you too dear.. "
            w "Would you like to paint with me?"
            t "Ill paint a heart with you"
            hide misssasha blush
            scene endpaint
            e "THANKS FOR PLAYING"

scene brickroom

e "The End"

e "PRODUCED AND PROGRAMMED BY Zymon BlueShade"

e "ORIGINAL CHARACTERS BY Katie"

e "SPRITE ART BY MiziCity" 

e "MUSIC BY Awaterbottlecap and Zymon BlueShade"

e "SPECIAL THANKS TO: On X/Twitter: @ChamanCriard0, @cyancroaltacc, @Xenclaire_, @Sadragdoll24, @sm00th_iecat, @FPESchool"

e "On other platforms: Edward, SuzuiDenzo, spigtap, C0dename_K, Bubble, Tom, Landfill_man, Cyn, Edith Mayeso, Sleepy Silly Modder"

e "UserUser510, RUSSIAN | STATUE, Laniki, gargos69juinor, Jayling"

e "Went_Nuts, Gordon, Huh?¿, Chaotic Zip, Fallenterror, Ney_2210zVT, GeneralCuyler, McMellon12, Animatic, Scientist TV man"

e "XxchildishgamingxX, J-Net Aerospace, MSC, Schoolius, Koriagrophy"

e "GAME MADE BY BLUESHADE DEVELOPMENT (NOT AFFILATED WITH KATIE)"

return